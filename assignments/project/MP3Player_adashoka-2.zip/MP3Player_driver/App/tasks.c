/************************************************************************************

Copyright (c) 2001-2016  University of Washington Extension.

Module Name:

    tasks.c

Module Description:

    The tasks that are executed by the test application.

2016/2 Nick Strathy adapted it for NUCLEO-F401RE 

************************************************************************************/
#include <stdarg.h>

#include "bsp.h"
#include "print.h"
#include "mp3Util.h"

#include <Adafruit_GFX.h>    // Core graphics library
#include <Adafruit_ILI9341.h>
#include <Adafruit_FT6206.h>

Adafruit_ILI9341 lcdCtrl = Adafruit_ILI9341(); // The LCD controller
Adafruit_FT6206 touchCtrl = Adafruit_FT6206(); // The touch controller
Adafruit_GFX_Button StartButton = Adafruit_GFX_Button();
Adafruit_GFX_Button PauseButton = Adafruit_GFX_Button();
Adafruit_GFX_Button StopButton = Adafruit_GFX_Button();
Adafruit_GFX_Button ForwardButton = Adafruit_GFX_Button();
Adafruit_GFX_Button RewindButton = Adafruit_GFX_Button();
Adafruit_GFX_Button VolumeUpButton = Adafruit_GFX_Button();
Adafruit_GFX_Button VolumeDownButton = Adafruit_GFX_Button();
Adafruit_GFX_Button SongUpButton = Adafruit_GFX_Button();
Adafruit_GFX_Button SongDownButton = Adafruit_GFX_Button();

#define PENRADIUS 3

long MapTouchToScreen(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}


#include "train_crossing.h"
#include "song1.h"

#define BUFSIZE 256
#define MAX_SONGS 15
#define MAX_SONGS_DISPLAY 9
#define LIST_DISPLAY_W 20
#define LIST_DISPLAY_H 28
#define SONG_SLOT_H 12
#define SONG_DOT_SPACING_W 8
#define SONG_DOT_SPACING_H 4
#define PROGRESS_BAR_H 180
#define PROGRESS_BAR_W 20
#define PROGRESS_BAR_WIDTH 200
#define PROGRESS_BAR_HEIGHT 5 

//song_list
char song_list[15][100] = {
    "Train Crossing - demo",
    "Bruce S. - This Land is Your Land",
    "Bob Dylan - Blowin In The Wind",
    {'s','o','n','g','3','\0'},
    {'s','o','n','g','4','\0'},
    {'s','o','n','g','5','\0'},
    {'s','o','n','g','6','\0'},
    {'s','o','n','g','7','\0'},
    {'s','o','n','g','8','\0'},
    {'s','o','n','g','9','\0'},
    {'s','o','n','g','1','0','\0'},
    {'s','o','n','g','1','1','\0'},
    {'s','o','n','g','1','2','\0'},
    {'s','o','n','g','1','3','\0'},
    {'s','o','n','g','1','4','\0'},
};


int song_size[15] = {
  sizeof(song0),
  sizeof(song1),
};

static uint8_t my_song_select = 0;

//task communication channel
OS_EVENT *mbox_mp3;
OS_EVENT *mbox_display;
OS_EVENT *semPrint;

/************************************************************************************

   Allocate the stacks for each task.
   The maximum number of tasks the application can have is defined by OS_MAX_TASKS in os_cfg.h

************************************************************************************/

static OS_STK   TouchControllerStk[APP_CFG_TASK_START_STK_SIZE];
static OS_STK   Mp3StreamTaskStk[APP_CFG_TASK_START_STK_SIZE];
static OS_STK   UpdateDisplayStk[APP_CFG_TASK_START_STK_SIZE];

     
// Task prototypes
void TouchController(void* pdata);
void Mp3StreamTask(void* pdata);
void UpdateDisplay(void* pdata);



// Useful functions
void PrintToLcdWithBuf(char *buf, int size, char *format, ...);

// Globals
BOOLEAN nextSong = OS_FALSE;

/************************************************************************************

   This task is the initial task running, started by main(). It starts
   the system tick timer and creates all the other tasks. Then it deletes itself.

************************************************************************************/
void StartupTask(void* pdata)
{
	char buf[BUFSIZE];

    PjdfErrCode pjdfErr;
    INT32U length;
    static HANDLE hSD = 0;
    static HANDLE hSPI = 0;

    PrintWithBuf(buf, BUFSIZE, "StartupTask: Begin\n");
    PrintWithBuf(buf, BUFSIZE, "StartupTask: Starting timer tick\n");

    //create mailbox
    mbox_mp3 = OSMboxCreate(NULL);
    mbox_display = OSMboxCreate(NULL);
    semPrint = OSSemCreate(1);

    // Start the system tick
    SetSysTick(OS_TICKS_PER_SEC);
    
    // Initialize SD card
    PrintWithBuf(buf, PRINTBUFMAX, "Opening handle to SD driver: %s\n", PJDF_DEVICE_ID_SD_ADAFRUIT);
    hSD = Open(PJDF_DEVICE_ID_SD_ADAFRUIT, 0);
    if (!PJDF_IS_VALID_HANDLE(hSD)) while(1);


    PrintWithBuf(buf, PRINTBUFMAX, "Opening SD SPI driver: %s\n", SD_SPI_DEVICE_ID);
    // We talk to the SD controller over a SPI interface therefore
    // open an instance of that SPI driver and pass the handle to 
    // the SD driver.
    hSPI = Open(SD_SPI_DEVICE_ID, 0);
    if (!PJDF_IS_VALID_HANDLE(hSPI)) while(1);
    
    length = sizeof(HANDLE);
    pjdfErr = Ioctl(hSD, PJDF_CTRL_SD_SET_SPI_HANDLE, &hSPI, &length);
    if(PJDF_IS_ERROR(pjdfErr)) while(1);

    // Create the test tasks
    PrintWithBuf(buf, BUFSIZE, "StartupTask: Creating the application tasks\n");

    // The maximum number of tasks the application can have is defined by OS_MAX_TASKS in os_cfg.h
    OSTaskCreate(Mp3StreamTask, (void*)0, &Mp3StreamTaskStk[APP_CFG_TASK_START_STK_SIZE-1], APP_TASK_TEST1_PRIO);
    OSTaskCreate(TouchController, (void*)0, &TouchControllerStk[APP_CFG_TASK_START_STK_SIZE-1], APP_TASK_TEST2_PRIO);
    OSTaskCreate(UpdateDisplay, (void*)0, &UpdateDisplayStk[APP_CFG_TASK_START_STK_SIZE-1], APP_TASK_TEST3_PRIO);

    // Delete ourselves, letting the work be done in the new tasks.
    PrintWithBuf(buf, BUFSIZE, "StartupTask: deleting self\n");
	OSTaskDel(OS_PRIO_SELF);
}


static void DrawLcdContents()
{
    char buf[BUFSIZE];
    OS_CPU_SR cpu_sr;
    
    // allow slow lower pri drawing operation to finish without preemption
    OS_ENTER_CRITICAL(); 
    lcdCtrl.fillScreen(ILI9341_BLACK);
    int width = ILI9341_TFTWIDTH/3;
    int height = 32;

 
    //draw song select window
    //##############################################################################################
    lcdCtrl.setCursor(85,6);
    lcdCtrl.setTextColor(ILI9341_WHITE);  
    lcdCtrl.setTextSize(1);
    PrintToLcdWithBuf(buf, 20,"EMBSYS-320");

    //draw song select window
    //##############################################################################################
    lcdCtrl.drawRect(1,25,239,110,ILI9341_WHITE);

    //draw progress bar window
    //##############################################################################################
    lcdCtrl.drawRect(PROGRESS_BAR_W,PROGRESS_BAR_H,PROGRESS_BAR_WIDTH,PROGRESS_BAR_HEIGHT,ILI9341_WHITE);

    //first row of buttons 
    //[Stop][Pause][Start]
    //##############################################################################################
    StartButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*0)),\
                           ILI9341_TFTHEIGHT-(height/2),\
                           width,height,ILI9341_YELLOW,ILI9341_BLACK,ILI9341_YELLOW,\
                           "Start",2);
    StartButton.drawButton();
    
    
    PauseButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*1)),\
                           ILI9341_TFTHEIGHT-(height/2),\
                           width,height,ILI9341_YELLOW,ILI9341_BLACK,ILI9341_YELLOW,\
                           "Pause",2);
    PauseButton.drawButton();
    
    
    StopButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*2)),\
                           ILI9341_TFTHEIGHT-(height/2),\
                           width,height,ILI9341_YELLOW,ILI9341_BLACK,ILI9341_YELLOW,\
                           "Stop",2);
    StopButton.drawButton();
    


    //second row of buttons
    //[<<][vol--][down]
    //##############################################################################################
    RewindButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*2)),\
                           ILI9341_TFTHEIGHT-(height + height/2),\
                           width,height,ILI9341_YELLOW,ILI9341_BLACK,ILI9341_YELLOW,\
                           "<<",2);
    RewindButton.drawButton();


    VolumeDownButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*1)),\
                           ILI9341_TFTHEIGHT-(height + height/2),\
                           width,height,ILI9341_YELLOW,ILI9341_BLACK,ILI9341_YELLOW,\
                           "vol--",2);
    VolumeDownButton.drawButton();

    SongDownButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*0)),\
                           ILI9341_TFTHEIGHT-(height + height/2),\
                           width,height,ILI9341_WHITE,ILI9341_BLACK,ILI9341_WHITE,\
                           "down",2);
    SongDownButton.drawButton();



    //third row of buttons
    //[forward][Vol++][song++]
    //##############################################################################################
    ForwardButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*2)),\
                           ILI9341_TFTHEIGHT-(height + height + height/2),\
                           width,height,ILI9341_YELLOW,ILI9341_BLACK,ILI9341_YELLOW,\
                           ">>",2);
    ForwardButton.drawButton();


    VolumeUpButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*1)),\
                           ILI9341_TFTHEIGHT-(height + height + height/2),\
                           width,height,ILI9341_YELLOW,ILI9341_BLACK,ILI9341_YELLOW,\
                           "vol++",2);
    VolumeUpButton.drawButton();

    SongUpButton.initButton(&lcdCtrl,\
                           ILI9341_TFTWIDTH-((width/2)+(width*0)),\
                           ILI9341_TFTHEIGHT-(height + height + height/2),\
                           width,height,ILI9341_WHITE,ILI9341_BLACK,ILI9341_WHITE,\
                           "up",2);
    SongUpButton.drawButton();


    OS_EXIT_CRITICAL();

}


static void SongPointer(uint8_t cumulative_touch_count,uint8_t direction)
{
  char buf[256];
  OS_CPU_SR cpu_sr;
  uint8_t bottom_flag=0;
  uint8_t start_of_list_flag = 0;
  PrintWithBuf(buf, 256, "song_pointer:%d\n",cumulative_touch_count);
  
  if(cumulative_touch_count == 0) {
    start_of_list_flag = 1;
  }
  
  OS_ENTER_CRITICAL(); 
  //if you are not at the bottom of the display screen -- at which point only the song list should move
  

  //previous dot
  //#####################
  //nothing to clear if you are at the top of the list
  //clear previous dot before you 
  //down
  if((direction == 0) && (cumulative_touch_count != 0)) {
    lcdCtrl.fillCircle(LIST_DISPLAY_W-SONG_DOT_SPACING_W, LIST_DISPLAY_H+((cumulative_touch_count-1)*SONG_SLOT_H)+SONG_DOT_SPACING_H, PENRADIUS, ILI9341_BLACK);
  }
  
  //up
  if(direction == 1) {
    lcdCtrl.fillCircle(LIST_DISPLAY_W-SONG_DOT_SPACING_W, LIST_DISPLAY_H+((cumulative_touch_count+1)*SONG_SLOT_H)+SONG_DOT_SPACING_H, PENRADIUS, ILI9341_BLACK);
  }

  //new dot
  //#####################
  lcdCtrl.fillCircle(LIST_DISPLAY_W-SONG_DOT_SPACING_W, LIST_DISPLAY_H+(cumulative_touch_count*SONG_SLOT_H)+SONG_DOT_SPACING_H, PENRADIUS, ILI9341_RED);
  
  OS_EXIT_CRITICAL();
}



static void  UpdateSongListDisplay(uint8_t cumulative_touch_count,uint8_t init,uint8_t dir)
{
  char buf[60];
  OS_CPU_SR cpu_sr;
  uint8_t clear_previous=1;
  uint8_t no_update=0;
  uint8_t row[9];
  uint8_t update_song_list_flag = 0;
  static uint8_t window_start_count;
  static uint8_t window_end_count;
  if(cumulative_touch_count == 0) {
    window_start_count = 0;
    window_end_count = MAX_SONGS_DISPLAY-1;
    if(init) {
      clear_previous = 0;
    }
    else {
      clear_previous = 1;
    }
    update_song_list_flag = 1;
  }
  else if(cumulative_touch_count > window_end_count) {
     window_start_count++;
     window_end_count++;
     update_song_list_flag = 1;
  }
  else if(cumulative_touch_count < window_start_count) {  
     window_start_count--;
     window_end_count--;
     update_song_list_flag = 1;
  }
  else {
    clear_previous = 0;
  }

  //PrintWithBuf(buf,BUFSIZE,"window_start_count:%d,window_end_count:%d,cumulative_count:%d\n",window_start_count,window_end_count,cumulative_touch_count);
  for(int i=0;i<9;i++) {
    row[i]=i;
  }
  //greater than song list window
  //overall touch count less than MAX_SONGS
  //count > 9 (9 because touch count starts from 1)
  //if((cumulative_touch_count > MAX_SONGS_DISPLAY-1)){
  //clear_flag being set means that the records need to be updated
  if(clear_previous) {
    if(dir) {
      row[0] = cumulative_touch_count - 8;
      row[1] = cumulative_touch_count - 7;
      row[2] = cumulative_touch_count - 6;
      row[3] = cumulative_touch_count - 5;
      row[4] = cumulative_touch_count - 4;
      row[5] = cumulative_touch_count - 3;
      row[6] = cumulative_touch_count - 2;
      row[7] = cumulative_touch_count - 1;
      row[8] = cumulative_touch_count - 0;
    }
    if(dir == 0) {
      row[0] = cumulative_touch_count;
      row[1] = cumulative_touch_count + 1;
      row[2] = cumulative_touch_count + 2;
      row[3] = cumulative_touch_count + 3;
      row[4] = cumulative_touch_count + 4;
      row[5] = cumulative_touch_count + 5;
      row[6] = cumulative_touch_count + 6;
      row[7] = cumulative_touch_count + 7;
      row[8] = cumulative_touch_count + 8;
    }
  }

  
  //PrintWithBuf(buf,BUFSIZE,"row0:%d,row1:%d,row2:%d,row3:%d,row4:%d,row5:%d,row6:%d,row7:%d,row8:%d\n",row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8]);

  //PrintWithBuf(buf, BUFSIZE, "LIST:base:%d, row0:%d, row1:%d, row2:%d \n",base_index,row_zero,row_one,row_two);
  if(no_update == 0) {
    OS_ENTER_CRITICAL();
    lcdCtrl.setTextColor(ILI9341_WHITE);  
    lcdCtrl.setTextSize(1);
    for(int r=0;r < MAX_SONGS_DISPLAY; r++) {
      lcdCtrl.setCursor(LIST_DISPLAY_W,LIST_DISPLAY_H+(r*SONG_SLOT_H));
      if(clear_previous) {
        //clear that specific slot
        for(int w = LIST_DISPLAY_W; w < LIST_DISPLAY_W+218; w++) {
          for(int h = 28+(r*12); h < (LIST_DISPLAY_H+(r*SONG_SLOT_H))+SONG_SLOT_H-2; h++) {
            lcdCtrl.drawPixel(w,h,ILI9341_BLACK);
          }//for
        }//for
      }//if
      if(update_song_list_flag) {
        PrintToLcdWithBuf(buf, 256,&song_list[row[r]][0]);
      }
    }//for
    OS_EXIT_CRITICAL();
  }

}


static void  UpdateProgressBar(uint8_t direction,int base,uint8_t clear_flag)
{
  OS_CPU_SR cpu_sr;
  uint16_t color;
  if(direction) {
    color = ILI9341_WHITE;
  }
  else {
    color = ILI9341_BLACK;
  }
  if(clear_flag == 1) {
    OS_ENTER_CRITICAL();
    for(int i = PROGRESS_BAR_W+1; i < PROGRESS_BAR_W+PROGRESS_BAR_WIDTH-1; i++) {
      for(int j = PROGRESS_BAR_H+1; j < PROGRESS_BAR_H+PROGRESS_BAR_HEIGHT-1; j++) {
        lcdCtrl.drawPixel(i,j,ILI9341_BLACK);
      }
    }
    OS_EXIT_CRITICAL();
  } else {
      OS_ENTER_CRITICAL();
        lcdCtrl.drawPixel(PROGRESS_BAR_W+base,PROGRESS_BAR_H+1,color);
        lcdCtrl.drawPixel(PROGRESS_BAR_W+base,PROGRESS_BAR_H+2,color);
        lcdCtrl.drawPixel(PROGRESS_BAR_W+base,PROGRESS_BAR_H+3,color);
      OS_EXIT_CRITICAL();
  }
}



/************************************************************************************
   Display Update
************************************************************************************/
void UpdateDisplay(void* pdata)
{
  PjdfErrCode pjdfErr;
  INT32U length;
  char *display_command;
  int progress_bar_base = 1;
  uint8_t song_size = 0;
  int c_bytes_elapsed=0;
  char buf[BUFSIZE];
  INT32U bytes_per_pixel;
  //pixel per byte; 200 pixel wide
  //


  

  //PrintWithBuf(buf, BUFSIZE, "song_size:%d | bytes_per_pixel:%d\n",sizeof(song1),bytes_per_pixel);

  uint8_t pixel_chunk = 0;
  uint8_t pixel_chunk_forward = 0;
  // Open handle to the LCD driver
  HANDLE hLcd = Open(PJDF_DEVICE_ID_LCD_ILI9341, 0);
  if (!PJDF_IS_VALID_HANDLE(hLcd)) while(1);

  HANDLE hSPI = Open(LCD_SPI_DEVICE_ID, 0);
  if (!PJDF_IS_VALID_HANDLE(hSPI)) while(1);

  length = sizeof(HANDLE);
  pjdfErr = Ioctl(hLcd, PJDF_CTRL_LCD_SET_SPI_HANDLE, &hSPI, &length);
  if(PJDF_IS_ERROR(pjdfErr)) while(1);

  //PrintWithBuf(buf, BUFSIZE, "Initializing LCD controller\n");
  lcdCtrl.setPjdfHandle(hLcd);
  lcdCtrl.begin();
  DrawLcdContents();
  UpdateSongListDisplay(0,1,1);
  SongPointer(0,0);
  int bytes_elapsed=1;
  int erase_bytes = 0;
  int song_point_counter = 0;
  //int forward_pixels = (2750/bytes_per_pixel);
  //PrintWithBuf(buf, BUFSIZE, "forward_pixels:%d\n",forward_pixels);
  int display_counter = 0;
  //update display
  while(1) {
      if(my_song_select == 0) {
   bytes_per_pixel = sizeof(song0)/200;
  }
  else if (my_song_select == 1) {
    bytes_per_pixel = sizeof(song1)/200;
  }
    display_command = (char*)OSMboxAccept(mbox_display);
    //FORWARD command
    if(strcmp(">>",display_command) == 0) {
      bytes_elapsed = bytes_elapsed + 2750;
      if((bytes_elapsed >= bytes_per_pixel)){
        bytes_elapsed = bytes_elapsed - bytes_per_pixel;
        UpdateProgressBar(1,progress_bar_base,0);
        progress_bar_base++;
      } 
      //PrintWithBuf(buf, BUFSIZE, "progress_bar_base:%d ; cw:%d\n",progress_bar_base,forward_pixels);
    }
    else if(strcmp("<<",display_command) == 0) {
      erase_bytes = erase_bytes + 2750;
      bytes_elapsed = bytes_elapsed - 2750;
      if((erase_bytes >= bytes_per_pixel) && (progress_bar_base > 1)){
         erase_bytes=0;
         UpdateProgressBar(0,progress_bar_base,0);
         progress_bar_base--;
      }
      if(bytes_elapsed < 0) {
        bytes_elapsed = 1;
      }
    }
    //PLAY mode
    else if(strcmp("p+",display_command) == 0) {
      bytes_elapsed = bytes_elapsed + 32;
      if(bytes_elapsed >= bytes_per_pixel) {
        bytes_elapsed = bytes_elapsed - bytes_per_pixel;
        UpdateProgressBar(1,progress_bar_base,0);
        progress_bar_base++;
      }
    }
    else if(strcmp("clr",display_command) == 0) {
      UpdateProgressBar(1,progress_bar_base,1);
      progress_bar_base=1;
      bytes_elapsed=1;
      erase_bytes = 0;
    }
    
    if((strcmp("down",display_command) == 0)) {
       if(my_song_select != MAX_SONGS-1) {
          my_song_select++;
          OSMboxPost(mbox_mp3,(void*)"new");
       }
      //[1] you start with dot at first song (hence -1)
      //[2] once you are at last song (equal to MAX_SONGS_DISPLAY)
      //you shuldn't increment (hence <, instead of <=)
      if(song_point_counter < MAX_SONGS_DISPLAY-1) {
        song_point_counter++;
        //PrintWithBuf(buf, BUFSIZE, "song_point_counter:%d\n",song_point_counter);
        SongPointer(song_point_counter,0);
      }
      if(display_counter < MAX_SONGS-1) {
        display_counter++;
        UpdateSongListDisplay(display_counter,0,1);
        //PrintWithBuf(buf, BUFSIZE, "--->song_point_counter:%d,--->display_counter:%d\n",song_point_counter,display_counter);
      }
      else {
        //you can display end point
      }
    }

    if((strcmp("up",display_command) == 0)) {
       if(my_song_select != 0) {
          my_song_select--;
          OSMboxPost(mbox_mp3,(void*)"new");
       }
      //if you are not at the top of the display window
      if(song_point_counter != 0) {
        song_point_counter--;
        SongPointer(song_point_counter,1);
      }
      //if you are not at the first song
      if(display_counter != 0) {
        display_counter--;
        UpdateSongListDisplay(display_counter,0,0);
      }
    }

    //OSTimeDly(20);
  }

}

/************************************************************************************

   Runs LCD/Touch demo code

************************************************************************************/
void TouchController(void* pdata)
{
    PjdfErrCode pjdfErr;
    INT32U length;

    char buf[BUFSIZE];
    PrintWithBuf(buf, BUFSIZE, "TouchController: starting\n");

    HANDLE hI2C = Open(PJDF_DEVICE_ID_I2C1,0);
    if (!PJDF_IS_VALID_HANDLE(hI2C)) while(1);

    // Call Ioctl on that handle to set the I2C device address to FT6206_ADDR
    pjdfErr = Ioctl(hI2C,PJDF_CTRL_I2C_SET_DEVICE_ADDRESS,(void *)FT6206_ADDR,&length);
    
    // Call setPjdfHandle() on the touch contoller to pass in the I2C handle
    touchCtrl.setPjdfHandle(hI2C);

    if (! touchCtrl.begin(40)) {  // pass in 'sensitivity' coefficient
        PrintWithBuf(buf, BUFSIZE, "Couldn't start FT6206 touchscreen controller\n");
        while (1);
    }
    
    int currentcolor = ILI9341_YELLOW;
    

    //detect touches on the screen
    while (1) { 
        OSTimeDly(10);
        boolean touched;
        
        touched = touchCtrl.touched();
        
        if (! touched) {
            OSTimeDly(5);
            continue;
        }
        
        TS_Point point;
        
        //get points
        point = touchCtrl.getPoint();
        
        //if spurious; go back to and detect new touch
        if (point.x == 0 && point.y == 0)
        {
            continue;
        }
        
        // transform touch orientation to screen orientation.
        TS_Point p = TS_Point();
        p.x = MapTouchToScreen(point.x, 0, ILI9341_TFTWIDTH, ILI9341_TFTWIDTH, 0);
        p.y = MapTouchToScreen(point.y, 0, ILI9341_TFTHEIGHT, ILI9341_TFTHEIGHT, 0);
        
        //lcdCtrl.fillCircle(p.x, p.y, PENRADIUS, currentcolor);
        //translate screen touch to commands


        //button press
        if(StartButton.contains(p.x,p.y)) {OSMboxPost(mbox_mp3,(void*)"start");}
        if(PauseButton.contains(p.x,p.y)) {OSMboxPost(mbox_mp3,(void*)"pause");}
        if(StopButton.contains(p.x,p.y)) {OSMboxPost(mbox_mp3,(void*)"stop");}

        if(SongDownButton.contains(p.x,p.y)) {
          OSMboxPost(mbox_display,(void*)"down");
        }
        if(VolumeDownButton.contains(p.x,p.y)) {OSMboxPost(mbox_mp3,(void*)"v-");}
        if(RewindButton.contains(p.x,p.y)) {
          OSMboxPost(mbox_mp3,(void*)"<<");
          OSMboxPost(mbox_display,(void*)"<<");
         }
        
        if(SongUpButton.contains(p.x,p.y)) {
          OSMboxPost(mbox_display,(void*)"up");
        }
        if(VolumeUpButton.contains(p.x,p.y)) {OSMboxPost(mbox_mp3,(void*)"v+");}
        if(ForwardButton.contains(p.x,p.y)) {
          OSMboxPost(mbox_mp3,(void*)">>");
          OSMboxPost(mbox_display,(void*)">>");
        }
        
        OSTimeDly(270);
    }//while
}//task
/************************************************************************************

   Runs MP3 demo code

************************************************************************************/
void Mp3StreamTask(void* pdata)
{
    PjdfErrCode pjdfErr;
    INT32U length;
    
    char buf[BUFSIZE];
    PrintWithBuf(buf, BUFSIZE, "Mp3StreamTask: starting\n");

    PrintWithBuf(buf, BUFSIZE, "Opening MP3 driver: %s\n", PJDF_DEVICE_ID_MP3_VS1053);
    // Open handle to the MP3 decoder driver
    HANDLE hMp3 = Open(PJDF_DEVICE_ID_MP3_VS1053, 0);
    if (!PJDF_IS_VALID_HANDLE(hMp3)) while(1);

    PrintWithBuf(buf, BUFSIZE, "Opening MP3 SPI driver: %s\n", MP3_SPI_DEVICE_ID);
    // We talk to the MP3 decoder over a SPI interface therefore
    // open an instance of that SPI driver and pass the handle to 
    // the MP3 driver.
    HANDLE hSPI = Open(MP3_SPI_DEVICE_ID, 0);
    if (!PJDF_IS_VALID_HANDLE(hSPI)) while(1);

    length = sizeof(HANDLE);
    pjdfErr = Ioctl(hMp3, PJDF_CTRL_MP3_SET_SPI_HANDLE, &hSPI, &length);
    if(PJDF_IS_ERROR(pjdfErr)) while(1);

    // Send initialization data to the MP3 decoder and run a test
    PrintWithBuf(buf, BUFSIZE, "Starting MP3 device test\n");
    Mp3Init(hMp3);
    int count = 0;
    char* mp3_command;
    
    uint8_t err;
    while (1)
    {
        OSTimeDly(500);
        PrintWithBuf(buf, BUFSIZE, "Begin streaming sound file  count=%d\n", ++count);
        PrintWithBuf(buf, BUFSIZE, "my_song_select : %d\n", my_song_select);
        mp3_command = (char*)OSMboxPend(mbox_mp3,0,&err);
        if((strcmp("start",mp3_command) == 0)) {
            //select song
            if(my_song_select == 0) {
              PrintWithBuf(buf, BUFSIZE, "TRAIN\n");
              Mp3Stream(hMp3, (INT8U*)song0, sizeof(song0),mbox_mp3,mbox_display); 
            }
            else if (my_song_select == 1) {
              PrintWithBuf(buf, BUFSIZE, "BRUCE\n");
              Mp3Stream(hMp3, (INT8U*)song1, sizeof(song1),mbox_mp3,mbox_display); 
            }
        }

        PrintWithBuf(buf, BUFSIZE, "Done streaming sound file  count=%d\n", count);
    }
}


// Renders a character at the current cursor position on the LCD
static void PrintCharToLcd(char c)
{
    lcdCtrl.write(c);
}

/************************************************************************************

   Print a formated string with the given buffer to LCD.
   Each task should use its own buffer to prevent data corruption.

************************************************************************************/
void PrintToLcdWithBuf(char *buf, int size, char *format, ...)
{
    va_list args;
    va_start(args, format);
    PrintToDeviceWithBuf(PrintCharToLcd, buf, size, format, args);
    va_end(args);
}




